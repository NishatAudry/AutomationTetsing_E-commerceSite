package com.bd.AutomationPractice;
import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class TestCase_7 extends OpenHomePage{
	@Test(priority = 0)
	public void Login() throws InterruptedException {
	driver.findElement(By.linkText("ACCOUNT")).click();
	driver.findElement(By.linkText("My Account")).click();
	driver.findElement(By.xpath("//input[@id='email']")).sendKeys("tanvirnsa@gmail.com");
	driver.findElement(By.xpath("//input[@id='pass']")).sendKeys("cQSXzZa@Bk24ZS8");
	driver.findElement(By.xpath("//button[@id='send2']")).click();
	
	//displaying recent order info
	try {
		assertEquals("RECENT ORDERS", driver.findElement(By.xpath("//h2[contains(text(),'Recent Orders')]")).getText());
		System.out.println("Recent order is displayed!!!!!!");
	} catch (Exception e) {
		System.out.println("Not displayed!!!!!!");
		// TODO: handle exception
	}
	//Thread.sleep(5000);
	//clickOnMyOrder
	driver.findElement(By.xpath("//a[contains(text(),'My Orders')]")).click();
	Thread.sleep(5000);
	//clickOnViewOrder\
	driver.findElement(By.xpath("//tr[@class='first odd']//a[contains(text(),'View Order')]")).click();
	//Thread.sleep(5000);
	}

	@Test(priority = 1)
	public void verifyStatusPending() throws InterruptedException {
		String pageTitle = driver.getTitle();
		System.out.println("Order ID :"+pageTitle.substring(8));
		String orderID = pageTitle.substring(8);
		
		//System.out.println("Page Title: "+orderID);
		try {
			assertEquals("ORDER #"+orderID+" - PENDING", driver.findElement(By.tagName("h1")).getText());
		 System.out.println("Verified!!!!!!Order is Pending............");
		} catch (Exception e) {
			System.out.println("Order Pending msg isn't displayed..");
			e.printStackTrace();
			// TODO: handle exception 
 
		}
		for (String handle : driver.getWindowHandles()) {
	    	driver.switchTo().window(handle);
	    	}
		driver.findElement(By.xpath("//a[normalize-space()='Print Order']")).click();//clickOnPrintOrder()
		Thread.sleep(3000);
		//*****Note:
		//can't get the locators of save button
		//can't verify order pdf has been saved or not(automation)***
		
	}

}
