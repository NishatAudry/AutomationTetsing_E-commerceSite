package com.bd.AutomationPractice;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
//import org.testng.Assert;
import org.testng.annotations.Test;

public class TestCase_3 extends OpenHomePage{

	@Test(priority=0)
	public void mobile_menu() throws InterruptedException {

		driver.findElement(By.xpath("//a[contains(text(),'Mobile')]")).click();

	    Thread.sleep(1000);

	}
	
	@Test(priority=1)
	public void clickOnAddtoCart() throws InterruptedException {
		driver.findElement(By.xpath("//div[3]/button/span/span")).click();
		WebElement qty = driver.findElement(By.xpath("//tbody/tr[1]/td[4]/input[1]"));
		qty.clear();
		qty.sendKeys("1000");
		driver.findElement(By.xpath("//tbody/tr[1]/td[4]/button[1]")).click();
		Thread.sleep(2000);
		
	}
	@Test(priority = 2)
	public void verifyErrMsg() {
		
    	  String exp = "* The maximum quantity allowed for purchase is 500.";
	      WebElement m = driver.findElement(By.xpath("//p[contains(text(),'* The maximum quantity allowed for purchase is 500')]"));
	      String actual = m.getText();
	      System.out.println("Error message is: "+ actual);
	     // Assert.assertEquals(exp, actual);
	      if(exp.equals(actual)) {
	    	  System.out.println("Verified!!!!!!");
	    	  
	      }
	      else {
	    	  System.out.println("NOT MATCHED!!!!!!!!");
	    	  
	      }
	}
	@Test(priority = 3)
	public void verifyCartEmpty() {
		driver.findElement(By.xpath("//span[contains(text(),'Empty Cart')]")).click();
		WebElement m = driver.findElement(By.xpath("//h1[contains(text(),'Shopping Cart is Empty')]"));
		String actualTitle = m.getText();
		String expTitle = "SHOPPING CART IS EMPTY";
		//Assert.assertEquals(actualTitle, expTitle);
		//***For analyzing the exceptions in detail,
        //one can also use methods like printStackTrace(),
        //toString(), and getMessage()***
		try {
	        assertEquals(actualTitle, expTitle); 
	      } catch (Exception e) { 
	    	  e.printStackTrace();
	      }
	  }
	
		
		
	}



