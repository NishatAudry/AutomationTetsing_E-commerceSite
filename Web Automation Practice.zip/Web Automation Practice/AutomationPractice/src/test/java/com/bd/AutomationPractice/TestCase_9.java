package com.bd.AutomationPractice;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class TestCase_9 extends OpenHomePage{
	@Test
	public void verifyDiscount() {
		driver.findElement(By.xpath("//a[contains(text(),'Mobile')]")).click();
		driver.findElement(By.xpath("//li[2]//div[1]//div[3]//button[1]//span[1]//span[1]")).click();
		driver.findElement(By.xpath("//input[@id='coupon_code']")).sendKeys("GURU50");
		driver.findElement(By.xpath("//span[contains(text(),'Apply')]")).click();
		
		//String Grnd_total_after_discount = driver.findElement(By.cssSelector("strong span[class='price']")).getText();
		
		
		
		
	}

}
