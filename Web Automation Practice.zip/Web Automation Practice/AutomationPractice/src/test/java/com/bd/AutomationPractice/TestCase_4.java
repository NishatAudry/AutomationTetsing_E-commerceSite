package com.bd.AutomationPractice;
import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class TestCase_4 extends OpenHomePage{
	@Test(priority=0)
	public void mobile_menu() throws InterruptedException {

		driver.findElement(By.xpath("//a[contains(text(),'Mobile')]")).click();

	    Thread.sleep(1000);
	    
	    //Add to compare for Sony X
	    driver.findElement(By.xpath("//div[3]/ul/li[2]/a")).click(); 
	    //sony
	    String MainMbl_1 = driver.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[2]/ol[1]/li[1]/p[1]/a[1]")).getText();
	    System.out.println("Main Mobile Name 1: "+MainMbl_1);
	    
	    //Add to compare for Iphone
	    driver.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[3]/ul[1]/li[2]/div[1]/div[3]/ul[1]/li[2]/a[1]")).click();
	    //iphone
	    String MainMbl_2 = driver.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[2]/ol[1]/li[2]/p[1]/a[1]")).getText();
	    System.out.println("Main Mobile Name 2:"+MainMbl_2);
	    
	    //click to compare button
	    driver.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[2]/div[1]/button[1]")).click();
	    Thread.sleep(1000);
	    
	    //switch to new window
	    for(String handle : driver.getWindowHandles()) {
	    	driver.switchTo().window(handle);
	    }
	    
	    String strHead = "COMPARE PRODUCTS";
	    System.out.println("Original Popup Title: "+strHead);
	    String compHead = driver.findElement(By.xpath("//h1[contains(text(),'Compare Products')]")).getText();
	    System.out.println("Expected PopUp Title : "+compHead);
	    
	    String PopMbl_1 = driver.findElement(By.xpath("//a[contains(text(),'Sony Xperia')]")).getText();
	    System.out.println("Popup Mobile Name 1: "+PopMbl_1);
	    String PopMbl_2 = driver.findElement(By.xpath("//a[contains(text(),'IPhone')]")).getText();
	    System.out.println("Popup Mobile Name 2: "+PopMbl_2);
	    
	    try {
	    	assertEquals(strHead, compHead);
			
		} catch (Exception e) {
			// TODO: handle exception
		} 
	    
	    
	    try {
	    	assertEquals(MainMbl_1, PopMbl_1);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	    
	    try {
	    	assertEquals(MainMbl_2, PopMbl_2);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	    
	    
	    
	}
	

}
