package com.bd.AutomationPractice;

import io.github.bonigarcia.wdm.WebDriverManager;

import java.io.File;
import java.io.IOException;
//import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class OpenHomePage {
	//static String quantity = "10";
	static String baseUrl = "http://live.techpanda.org/index.php/";

	WebDriver driver;

	@SuppressWarnings("deprecation")
	@BeforeSuite

	public void Test_1() {

		WebDriverManager.chromedriver().setup();
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(co);

//WebDriverManager.firefoxdriver().setup();
//driver = new FirefoxDriver();
		driver.get(baseUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@AfterSuite
	public void end() throws InterruptedException, IOException {
		Thread.sleep(2000);
//Date currentDate = new Date();
//String screenshotFileName = currentDate.toString().replace(" ","-");
//System.out.println(screenshotFileName);

		File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshotFile, new File(".//screenshot/screen1.png"));
		driver.quit();

	}

}
