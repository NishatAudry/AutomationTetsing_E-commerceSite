package com.bd.AutomationPractice;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;


public class TestCase_8 extends OpenHomePage{
	@Test(priority = 0)
	public void Login() throws InterruptedException {
	driver.findElement(By.linkText("ACCOUNT")).click();
	driver.findElement(By.linkText("My Account")).click();
	driver.findElement(By.xpath("//input[@id='email']")).sendKeys("tanvirnsa@gmail.com");
	driver.findElement(By.xpath("//input[@id='pass']")).sendKeys("cQSXzZa@Bk24ZS8");
	driver.findElement(By.xpath("//button[@id='send2']")).click();
	}
	
	@Test(priority = 1)
	public void reorder() {
		driver.findElement(By.linkText("REORDER")).click();
		//change quality , click update
		WebElement qty = driver.findElement(By.xpath("//tbody/tr[1]/td[4]/input[1]"));
		qty.clear();
		qty.sendKeys();
		driver.findElement(By.xpath("//tbody/tr[1]/td[4]/button[1]")).click();
		
	}
	
	@Test(priority = 2)
	public void verifyGrandTotal() {
		String prd_cost$ = driver.findElement(By.cssSelector("td[class='product-cart-price'] span[class='price']")).getText();
		//System.out.println("Product Price = "+prd_cost$.substring(1));
		
		//String prd_cost = prd_cost$.substring(1);
		 float pc_float=Float.parseFloat(prd_cost$.substring(1));
		 System.out.println("Product Price = "+pc_float);
		 
		 String grnd_total = driver.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/div[1]/table[1]/tfoot[1]/tr[1]/td[2]/strong[1]/span[1]")).getText();
		 
		 int grnd_total_float_1=Integer.parseInt(grnd_total.substring(1,2));
		 int grnd_total_float_2=Integer.parseInt(grnd_total.substring(3,6));
		 //System.out.println("Total Price = "+grnd_total_float_2);

		 String grnd_total_append= grnd_total.substring(1,2).concat(grnd_total.substring(3,6));  
		 float grnd_total_org =Float.parseFloat(grnd_total_append);
		 
		 System.out.println("Original Grand Total = "+grnd_total_org);
		 
		// int qty_int =Integer.parseInt(quantity);  
		
		 
		 
		 float exp_grnd_total = (float) ((pc_float * 10));
		 System.out.println("Expected Grand Total = "+exp_grnd_total);
		 
		 try {
			assertEquals(grnd_total_org , exp_grnd_total);
			System.out.println("Verified!!!! Grand Total is changed...");
		} catch (Exception e) {
			System.out.println("Grand Total is not changed...");
			// TODO: handle exception
		}
		 
	}
	@Test(priority = 3)
	public void billingInfo() {
	        WebElement ddown_1 = driver.findElement(By.xpath("//select[@id='country']"));
			ddown_1.click();
			Select select1 = new Select(ddown_1);
			select1.selectByVisibleText("United States");
			WebElement ddown_2 = driver.findElement(By.xpath("//select[@id='region_id']"));
			ddown_2.click();
			Select select2 = new Select(ddown_2);
			select2.selectByVisibleText("New York");
			driver.findElement(By.xpath("//input[@id='postcode']")).sendKeys("1234");
			driver.findElement(By.xpath("//span[contains(text(),'Estimate')]")).click();
			//shipping cost radio button
			driver.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/form[2]/dl[1]/dd[1]/ul[1]/li[1]/label[1]")).click();
			driver.findElement(By.xpath("//span[contains(text(),'Update Total')]")).click();
			
			//proceed to checkout
			driver.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[1]/button[1]")).click();
			driver.findElement(By.xpath("//label[contains(text(),'Ship to this address')]")).click();
			driver.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[1]/ol[1]/li[1]/div[2]/form[1]/div[1]/div[1]/button[1]")).click();
			
			driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[2]/div[1]/div[1]/ol[1]/li[3]/div[2]/form[1]/div[3]/button[1]/span[1]/span[1]")).click();
			driver.findElement(By.xpath("//label[contains(text(),'Check / Money order')]")).click();
			driver.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[1]/ol[1]/li[4]/div[2]/div[2]/button[1]")).click();
			driver.findElement(By.xpath("//span[contains(text(),'Place Order')]")).click();
			
			String org_OrderPlaceMsg = "YOUR ORDER HAS BEEN RECEIVED.";
			String exp_OrderPlaceMsg = driver.findElement(By.xpath("//h1[contains(text(),'Your order has been received.')]")).getText();
			System.out.println("Order Place Message : "+exp_OrderPlaceMsg);
			
			try {
				assertEquals(org_OrderPlaceMsg, exp_OrderPlaceMsg);
				System.out.println("Order is placed!!!!!!!!");
			} catch (Exception e) {
				System.out.println("Order is not placed!!!!");
				// TODO: handle exception
			}
			
			String orderID = driver.findElement(By.cssSelector("body.checkout-onepage-success:nth-child(2) div.wrapper:nth-child(1) div.page:nth-child(2) div.main-container.col1-layout div.main div.col-main p:nth-child(3) > a:nth-child(1)")).getText();
			System.out.println("Order Id : "+orderID);
	}
	

}
