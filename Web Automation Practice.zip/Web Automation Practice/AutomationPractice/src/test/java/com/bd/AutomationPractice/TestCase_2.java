package com.bd.AutomationPractice;


import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class TestCase_2 extends OpenHomePage{
	@Test(priority=0)
	public void mobile_menu() throws InterruptedException {

		driver.findElement(By.xpath("//a[contains(text(),'Mobile')]")).click();
		driver.findElement(By.id("product-collection-image-1")).click();
		String actualdata = driver.findElement(By.className("price")).getText();
		System.out.println("Detail Price : "+actualdata);
		
		String expectedData = "$100.00";
		
		if(actualdata.equals(expectedData)) {
			System.out.println("Product value in list and details page is equal($100.00)");
			
		}
		else {
			System.out.println("Not equal");
		}

	    Thread.sleep(2000);

	}

}
