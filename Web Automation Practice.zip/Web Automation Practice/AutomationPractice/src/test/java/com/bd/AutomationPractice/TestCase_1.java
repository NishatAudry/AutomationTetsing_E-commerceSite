package com.bd.AutomationPractice;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;

import org.openqa.selenium.WebElement;

import org.testng.annotations.Test;

import org.openqa.selenium.support.ui.*;

public class TestCase_1 extends OpenHomePage{

		@Test(priority=0)
		public void Verify_Title_HomePage() {

			String title = driver.getTitle();

			System.out.println(title);

			String actual = "Home page";

			if(title.equals(actual)) {

				System.out.println("Verified!!!!!!");

			}

		}

			@Test(priority=1)

			

			public void mobile_menu() throws InterruptedException {

				driver.findElement(By.xpath("//a[contains(text(),'Mobile')]")).click();

			    Thread.sleep(5000);

			}



		

		@Test(priority=2)

		public void Verify_Title_MobilePage() {

				

				String title = driver.getTitle();

				System.out.println(title);

				String actual = "Mobile";

				if(title.equals(actual)) {

					System.out.println("Verified!!!!!!");

				}

			}

		@Test(priority=3)

		public void Dropdown() {

			//WebElement ddown = driver.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[3]/div[2]/div[1]/div[1]/div[1]/select"));

			//WebElement ddown = driver.findElement(By.cssSelector(".category-products > .toolbar > .sorter select"));
			WebElement ddown = driver.findElement(By.tagName("select"));
			ddown.click();

			Select select = new Select(ddown);

			select.selectByVisibleText("Name");		

		}
@SuppressWarnings("unchecked")
@Test(priority=4)	
public void Sort() {
	WebElement ddown = driver.findElement(By.tagName("select"));
	Select select = new Select(ddown);
	List originalList = new ArrayList();
	List tempList = new ArrayList();
	List<WebElement>options = select.getOptions();
	
	for(WebElement w:options) {
		originalList.add(w.getText());
		tempList.add(w.getText());
		
	   }
	System.out.println("Before Sorting: "+originalList);
	
	Collections.sort(tempList);	
	

	System.out.println("After Sorting: "+tempList);
	
	if(originalList.equals(tempList)) {
		System.out.println("Sorted!!!!");
	}
	else {
		System.out.println("NOT SORTED!!!!!!!!!!!!!");
	}
	
    }





}




