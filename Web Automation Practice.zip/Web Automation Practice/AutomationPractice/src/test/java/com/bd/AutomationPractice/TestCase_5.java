package com.bd.AutomationPractice;

import static org.testng.Assert.assertEquals;
//import static org.testng.Assert.expectThrows;

import java.util.Random;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class TestCase_5 extends OpenHomePage{

		@Test(priority=0)
		public void creatingAccount() throws InterruptedException {

			driver.findElement(By.xpath("//header/div[1]/div[2]/div[1]/a[1]/span[2]")).click();
			driver.findElement(By.xpath("//header/div[1]/div[5]/div[1]/ul[1]/li[1]/a[1]")).click();
			driver.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/form[1]/div[1]/div[1]/div[2]/a[1]")).click();
			
			driver.findElement(By.xpath("//input[@id='firstname']")).sendKeys("Nishat");
			driver.findElement(By.xpath("//input[@id='lastname']")).sendKeys("Sharmin");
			driver.findElement(By.xpath("//input[@id='email_address']")).sendKeys(getSaltString()+"@gmail.com");
			driver.findElement(By.xpath("//input[@id='password']")).sendKeys("123456");
			driver.findElement(By.xpath("//input[@id='confirmation']")).sendKeys("123456");
			driver.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/form[1]/div[2]/button[1]")).click();

		    Thread.sleep(1000);
		}
		//random email generator
		protected String getSaltString() {
	        String allowChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_1234567890";
	        StringBuilder str = new StringBuilder();
	        Random rand = new Random();
	        while (str.length() < 10) { // length of the random string.
	            int index = (int) (rand.nextFloat() * allowChars.length());//rand.nextfloat()-->0.0-0.1 random num generator
	            str.append(allowChars.charAt(index));//append the random character at that index
	        }
	        String allowStr = str.toString();
	        return allowStr;

	    }
		@Test(priority=1)
		public void verifyRegistration() {
			String OriginalText = "WELCOME, NISHAT SHARMIN!";
			String ExpectedText = driver.findElement(By.xpath("//p[contains(text(),'Welcome, Nishat Sharmin!')]")).getText();
			System.out.println("Registration Name: "+ExpectedText);
			
			try {
				assertEquals(OriginalText,ExpectedText);
				System.out.println("Verified!!!!!!!!!!!!");
			} catch (Exception e) {
				// TODO: handle exception
			}
			
		
		}
		@Test(priority=2)
       public void shareWishlist(){
    	   driver.findElement(By.xpath("//a[contains(text(),'TV')]")).click();
    	   driver.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[2]/ul[1]/li[1]/div[1]/div[3]/ul[1]/li[1]/a[1]")).click();
		   driver.findElement(By.xpath("//span[contains(text(),'Share Wishlist')]")).click();
		   
		   driver.findElement(By.xpath("//textarea[@id='email_address']")).sendKeys("nishataudry0652@gmail.com , tanvirnsa@gmail.com");
		   driver.findElement(By.xpath("//textarea[@id='message']")).sendKeys("I am here to test you!!!");
		   
		   driver.findElement(By.xpath("//span[contains(text(),'Share Wishlist')]")).click();
		   
		}
		
		@Test(priority=3)
		public void verifyWishlistShared() {
			String OriginalMsg = "Your Wishlist has been shared.";
			String expectedMsg = driver.findElement(By.xpath("//span[contains(text(),'Your Wishlist has been shared.')]")).getText();
			System.out.println("Expected Msg : "+expectedMsg);
			
			try {
				assertEquals(OriginalMsg, expectedMsg);
				System.out.println("Verified! Succcessfully shared.....");
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		

}
