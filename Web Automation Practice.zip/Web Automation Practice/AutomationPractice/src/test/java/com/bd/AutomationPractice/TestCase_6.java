package com.bd.AutomationPractice;
import static org.testng.Assert.assertEquals;
//import org.bouncycastle.asn1.mozilla.PublicKeyAndChallenge;
import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
public class TestCase_6 extends OpenHomePage{
	//WebDriver driver;
	@Test(priority = 0)
	public void Login() {
	driver.findElement(By.linkText("ACCOUNT")).click();
	driver.findElement(By.linkText("My Account")).click();
	driver.findElement(By.xpath("//input[@id='email']")).sendKeys("tanvirnsa@gmail.com");
	driver.findElement(By.xpath("//input[@id='pass']")).sendKeys("cQSXzZa@Bk24ZS8");
	driver.findElement(By.xpath("//button[@id='send2']")).click();
	}
	@Test(priority = 2)
	public void addToWishlist() {
	driver.findElement(By.xpath("//a[contains(text(),'TV')]")).click();
	driver.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[2]/ul[1]/li[1]/div[1]/div[3]/ul[1]/li[1]/a[1]")).click();
	driver.findElement(By.linkText("MY WISHLIST")).click();
	}
	
	@Test(priority = 3)
	public void verifyShippingCost() throws InterruptedException
	{
	driver.findElement(By.xpath("//button[@type='button']//span//span[contains(text(),'Add to Cart')]")).click();
	Thread.sleep(5000);
	
//	**Quanity Update** 
	WebElement qty = driver.findElement(By.xpath("//tbody/tr[1]/td[4]/input[1]"));
	qty.clear();
	qty.sendKeys("1");
	driver.findElement(By.xpath("//tbody/tr[1]/td[4]/button[1]")).click();
	
	WebElement ddown_1 = driver.findElement(By.xpath("//select[@id='country']"));
	ddown_1.click();
	Select select1 = new Select(ddown_1);
	select1.selectByVisibleText("United States");
	WebElement ddown_2 = driver.findElement(By.xpath("//select[@id='region_id']"));
	ddown_2.click();
	Select select2 = new Select(ddown_2);
	select2.selectByVisibleText("New York");
	driver.findElement(By.xpath("//input[@id='postcode']")).sendKeys("1234");
	driver.findElement(By.xpath("//span[contains(text(),'Estimate')]")).click();
	String org_ship_cost = "Fixed - $5.00";
	System.out.println("Original Shipping Cost = "+org_ship_cost);
	String exp_ship_cost = driver.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/form[2]/dl[1]/dd[1]/ul[1]/li[1]/label[1]")).getText();
	System.out.println("Expected Shipping Cost = "+exp_ship_cost);
	try {
	assertEquals(org_ship_cost, exp_ship_cost);
	System.out.println("Verified Shipping cost..!!!!!!!!!!!!!!!!");
	} catch (Exception e) {
	// TODO: handle exception
	}
}
	@Test(priority = 4)
	public void verifyGrandTotal() {
	driver.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/form[2]/dl[1]/dd[1]/ul[1]/li[1]/label[1]")).click();
	driver.findElement(By.xpath("//span[contains(text(),'Update Total')]")).click();
	String product_cost = driver.findElement(By.xpath("//tbody/tr[1]/td[2]/span[1]")).getText();
	//System.out.println(product_cost);
	
	 float pc_float=Float.parseFloat(product_cost.substring(1));
	 System.out.println("Product Cost = $"+pc_float);
	 String shipping_cost = driver.findElement(By.xpath("//tbody/tr[2]/td[2]/span[1]")).getText();
	 float sc_float=Float.parseFloat(shipping_cost.substring(1));
	 System.out.println("Shipping Cost = $"+sc_float);
	
	 float exp_grand_total = pc_float + sc_float;
	
	 String grand_total = driver.findElement(By.xpath("//table[@id='shopping-cart-totals-table']/tfoot/tr/td[2]/strong")).getText();
	 float org_grand_total = Float.parseFloat(grand_total.substring(1));
	 System.out.println("Original Grand Total = $"+org_grand_total);
	
	 try {
		assertEquals(org_grand_total, exp_grand_total);
		System.out.println("Verified!!Shipping cost is added to Grand Total........");
	} catch (Exception e) {
		// TODO: handle exception
	}
	
	}
	@Test(priority = 5)
	public void placeOrder() {
		//proceed to checkout
		driver.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[1]/button[1]")).click();
		driver.findElement(By.xpath("//label[contains(text(),'Ship to this address')]")).click();
		driver.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[1]/ol[1]/li[1]/div[2]/form[1]/div[1]/div[1]/button[1]")).click();
		
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[2]/div[1]/div[1]/ol[1]/li[3]/div[2]/form[1]/div[3]/button[1]/span[1]/span[1]")).click();
		driver.findElement(By.xpath("//label[contains(text(),'Check / Money order')]")).click();
		driver.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[1]/ol[1]/li[4]/div[2]/div[2]/button[1]")).click();
		driver.findElement(By.xpath("//span[contains(text(),'Place Order')]")).click();
		
		String org_OrderPlaceMsg = "YOUR ORDER HAS BEEN RECEIVED.";
		String exp_OrderPlaceMsg = driver.findElement(By.xpath("//h1[contains(text(),'Your order has been received.')]")).getText();
		System.out.println("Order Place Message : "+exp_OrderPlaceMsg);
		
		try {
			assertEquals(org_OrderPlaceMsg, exp_OrderPlaceMsg);
			System.out.println("Order is placed!!!!!!!!");
		} catch (Exception e) {
			System.out.println("Order is not placed!!!!");
			// TODO: handle exception
		}
		
		String orderID = driver.findElement(By.cssSelector("body.checkout-onepage-success:nth-child(2) div.wrapper:nth-child(1) div.page:nth-child(2) div.main-container.col1-layout div.main div.col-main p:nth-child(3) > a:nth-child(1)")).getText();
		System.out.println("Order Id : "+orderID);
		
	}
//	@Test(priority = 6)
//	public void clickToMyAcc() {
//		
//		driver.findElement(By.xpath("//a[@class='skip-link skip-account']")).click();
//		driver.findElement(By.xpath("//div[@id='header-account']//a[@title='My Account'][normalize-space()='My Account']")).click();
//		
//		
//		driver.findElement(By.xpath("//tr[@class='first odd']//a[contains(text(),'View Order')]")).click();
//		
//		
//		//driver.switchTo().frame("google_esf");
//		
//		
//		
//	}
//	@Test(priority = 1)
//	public void recentOrderInfo() {
//		//String recentOrder = driver.findElement(By.xpath("//h2[contains(text(),'Recent Orders')]")).getText();
//		try {
//			assertEquals("RECENT ORDERS", driver.findElement(By.xpath("//h2[contains(text(),'Recent Orders')]")).getText());
//			System.out.println("Recent order is displayed!!!!!!");
//		} catch (Exception e) {
//			System.out.println("Not displayed!!!!!!");
//			// TODO: handle exception
//		}
//		
//	}
//	@Test(priority = 7)
//	public void verifyStatusPending() {
//		String orderID = driver.findElement(By.cssSelector("body.checkout-onepage-success:nth-child(2) div.wrapper:nth-child(1) div.page:nth-child(2) div.main-container.col1-layout div.main div.col-main p:nth-child(3) > a:nth-child(1)")).getText();
//		try {
//			assertEquals("Order#"+orderID+"-PENDING", driver.findElement(By.cssSelector("body.sales-order-view.customer-account:nth-child(2) div.wrapper:nth-child(1) div.page:nth-child(2) div.main-container.col2-left-layout div.main div.col-main:nth-child(2) div.my-account div.page-title.title-buttons:nth-child(1) > h1:nth-child(1)")).getText());
//		 System.out.println("Verified!!!!!!Order is Pending............");
//		} catch (Exception e) {
//			System.out.println("Order Pending msg isn't displayed..");
//			// TODO: handle exception
//		}
//		
//	}
//	@Test(priority = 8)
//	 public void clickOnPrintOrder() {
//		
//		 driver.findElement(By.xpath("//a[normalize-space()='Print Order']")).click();
//		 //can't get the locators of save button
//		 //can't verify order pdf has been saved or not(automation)
//	 }
}

	



